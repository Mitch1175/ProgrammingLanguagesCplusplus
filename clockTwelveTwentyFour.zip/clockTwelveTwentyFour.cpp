/* 
Mitchel Dauk
02/06/2024
CS-210-R3198
Programming Languages
Project One
*/

// Adds header files
#include <iostream>
#include <iomanip>
using namespace std; // User names are from the standard library



// Creates a function that calls hour, minute, second, and the 12 hour clock
void clockT(int& hour, int& minute, int& second, int& hourT) {


	bool quit = false; // Allows the program to quit if called
	int choice; // initializes integer choice

	while (!quit) { // Creates a loop when quit is not selected

		// Box One and Two. Top Line
		cout << setfill('*') << setw(26) << left << "";            // Fills 26 spaces with *
		cout << setfill(' ') << setw(6) << left << "";             // Fills 6 spaces next to *
		cout << setfill('*') << setw(26) << right << "" << endl;   // Fills 26 spaces with *

		// Second Line (Clock Names)
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(6) << left << "";
		cout << "12-Hour Clock";
		cout << setfill(' ') << setw(5) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(6) << left << "";
		cout << setfill('*') << setw(1) << right << "";
		cout << setfill(' ') << setw(6) << right << "";
		cout << "24-Hour Clock";
		cout << setfill(' ') << setw(5) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		// Third Line (Clock Display)
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(8) << left << "";
		cout << right << setfill('0') << setw(2) << hourT << ":";   // Fills a 0 in if it is a single digit
		cout << right << setfill('0') << setw(2) << minute << ":";  // Fills a 0 in if it is a single digit
		cout << right << setfill('0') << setw(2) << second;         // Fills a 0 in if it is a single digit

		// Initializes AM or PM and prints it after the time
		if (hour > 11) {
			cout << " PM";
		}
		else {
			cout << " AM";
		}

		cout << setfill(' ') << setw(5) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(6) << left << "";
		cout << setfill('*') << setw(1) << right << "";
		cout << setfill(' ') << setw(8) << right << "";
		cout << right << setfill('0') << setw(2) << hour << ":";     // Fills a 0 in if it is a single digit
		cout << right << setfill('0') << setw(2) << minute << ":";   // Fills a 0 in if it is a single digit
		cout << right << setfill('0') << setw(2) << second;          // Fills a 0 in if it is a single digit
		cout << setfill(' ') << setw(8) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		// Bottom Line
		cout << setfill('*') << setw(26) << left << "";
		cout << setfill(' ') << setw(6) << left << "";
		cout << setfill('*') << setw(26) << right << "" << endl;


		//Box Three
		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(26) << "" << endl;

		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(1) << left << "";
		cout << "1 - Add One Hour";
		cout << setfill(' ') << setw(7) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(1) << left << "";
		cout << "2 - Add One Minute";
		cout << setfill(' ') << setw(5) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(1) << left << "";
		cout << "3 - Add One Second";
		cout << setfill(' ') << setw(5) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(1) << left << "";
		cout << setfill(' ') << setw(1) << left << "";
		cout << "4 - Exit Program";
		cout << setfill(' ') << setw(7) << right << "";
		cout << setfill('*') << setw(1) << right << "" << endl;

		cout << setfill(' ') << setw(16) << left << "";
		cout << setfill('*') << setw(26) << "" << endl;

		cout << endl << "Please make a selection" << endl;

		cin >> choice;      // Allows the user to pick a number from the switch case

		switch (choice) {   // Allows the user to pick a number

		case 1:
			hour = (hour + 1) % 24;               // Adds 1 hour if 1 is picked (24-hour clock)
			hourT = (hourT + 1) % 13;             // Adds 1 hour if 1 is picked (12-hour clock)
			cout << "One Hour Added" << endl;     // Prints if hour was added
			break;

		case 2:
			minute = (minute + 1) % 60;           // Adds 1 minute if 2 is picked
			cout << "One Minute Added" << endl;   // Prints if minute was added
			if (minute == 0) {                    // If a minute is added to 59, it will add 1 hour
				hour = hour + 1;
			}
			else {
				minute == minute;
			}
			break;

		case 3:
			second = (second + 1) % 60;            // Adds 1 second if 3 is picked
			cout << "One Second Added" << endl;    // Prints if second was added
			if (second == 00) {                    // If a second is added to 59, it will add 1 minute
				minute = minute + 1;
			}
			else {
				second == second;
			}
			break;

		case 4:
			cout << "Goodbye" << endl;             // Quits program if 4 is picked
			quit = true;
			break;

		default:  // Tells the user what they picked is invalid and allows the user to repick a number
			cout << "Invalid. Please select a number between 1 and 4." << endl;  
			break;
		}


		// Makes sure the clock continues from 12 to 1 and not 12 to 0
		if (hourT == 0) {
			hourT = 01;
		}
		else {
			(hourT = hourT);
		}


		// Makes sure minutes do not equal 60 when seconds pass 59
		if (minute == 60) { 
			minute = 00;
		}
		else {
			minute = minute;
		}


		// If the second and the minute pass 59, 1 hour will be added
		if ((second == 00) && (minute == 00)) {
			hour = hour + 1;
		}
		else {
			hour = hour;
		}


		// Translates 24-hour clock to 12-hour clock
		if (hour == 13) {
			hourT = 01;
		}
		else if (hour == 14) {
			hourT = 02;
		}
		else if (hour == 15) {
			hourT = 03;
		}
		else if (hour == 16) {
			hourT = 04;
		}
		else if (hour == 17) {
			hourT = 05;
		}
		else if (hour == 18) {
			hourT = 06;
		}
		else if (hour == 19) {
			hourT = 07;
		}
		else if (hour == 20) {
			hourT = 8;
		}
		else if (hour == 21) {
			hourT = 9;
		}
		else if (hour == 22) {
			hourT = 10;
		}
		else if (hour == 23) {
			hourT = 11;
		}
		else if (hour == 00) {
			hourT = 12;
		}
		else {
			(hour == 1);
			hourT == 01;
		}
	}
}



int main() {

	// Initialized the integers hour, minute, second, and hourT
	int hour = (rand() % 24); // Starts the program with a random number
	int minute = rand() % 60; // Starts the program with a random number
	int second = rand() % 60; // Starts the program with a random number
	int hourT = hour - 12;    // Starts the program so the 12-hour clock isn't the same as the 24-hour clock

	// Runs the function clockT
	clockT(hour, minute, second, hourT);
	
	return 0;
}